/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'brLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'acre': '&#xe900;',
            'ac': '&#xe900;',
            'alagoas': '&#xe901;',
            'al': '&#xe901;',
            'amapá': '&#xe902;',
            'ap': '&#xe902;',
            'amazonas': '&#xe903;',
            'am': '&#xe903;',
            'bahia': '&#xe904;',
            'ba': '&#xe904;',
            'brasil': '&#xe905;',
            'br': '&#xe905;',
            'ceará': '&#xe906;',
            'ce': '&#xe906;',
            'destrito federal': '&#xe907;',
            'df': '&#xe907;',
            'espirito santo': '&#xe908;',
            'es': '&#xe908;',
            'goiás': '&#xe909;',
            'go': '&#xe909;',
            'maranhão': '&#xe90a;',
            'ma': '&#xe90a;',
            'mato grosso do sul': '&#xe90b;',
            'ms': '&#xe90b;',
            'mato grosso': '&#xe90c;',
            'mt': '&#xe90c;',
            'minas gerais': '&#xe90d;',
            'mg': '&#xe90d;',
            'pará': '&#xe90e;',
            'pa': '&#xe90e;',
            'paraíba': '&#xe90f;',
            'pb': '&#xe90f;',
            'paraná': '&#xe910;',
            'pr': '&#xe910;',
            'pernambuco': '&#xe911;',
            'pe': '&#xe911;',
            'piauí': '&#xe912;',
            'pi': '&#xe912;',
            'rio de janeiro': '&#xe913;',
            'rj': '&#xe913;',
            'rio grande do norte': '&#xe914;',
            'rn': '&#xe914;',
            'rio grande do sul': '&#xe915;',
            'rs': '&#xe915;',
            'rondônia': '&#xe916;',
            'ro': '&#xe916;',
            'roraima': '&#xe917;',
            'rr': '&#xe917;',
            'santa catarina': '&#xe918;',
            'sc': '&#xe918;',
            'são paulo': '&#xe919;',
            'sp': '&#xe919;',
            'sergipe': '&#xe91a;',
            'se': '&#xe91a;',
            'tocantins': '&#xe91b;',
            'to': '&#xe91b;',
          '0': 0
        };
        delete icons['0'];
        window.brLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/br-liga/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.brLiga();
    }
}());
